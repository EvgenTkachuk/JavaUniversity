package ua.lab.devices;

import java.util.Scanner;

/**
 * Main — точка входу для Лабораторної роботи №1.
 *
 * Демонструє:
 *   1. Конструктори з параметрами
 *   2. Поліморфізм через AbstractDevice[]
 *   3. Методи доступу get / set
 *   4. Методи керування станом
 *   5. Статичний лічильник
 *   6. Діалоговий конструктор (Scanner)
 */
public class Main {

    public static void main(String[] args) {

        System.out.println("╔══════════════════════════════════════════════════════════╗");
        System.out.println("║  Лабораторна робота №1 — Варіант 11                     ║");
        System.out.println("║  Класи та спадкування у мові Java                       ║");
        System.out.println("║  Предметна область: Вимірювальні прилади                ║");
        System.out.println("╚══════════════════════════════════════════════════════════╝\n");

        // ══════════════════════════════════════════════════════════════════════
        // 1. КОНСТРУКТОРИ З ПАРАМЕТРАМИ
        // ══════════════════════════════════════════════════════════════════════
        System.out.println("▶ 1. Створення об'єктів — конструктор з параметрами");
        System.out.println("─".repeat(60));

        // DeviceBase: name, basePrice, voltage, current, frequency
        DeviceBase voltmeter = new DeviceBase(
            "Вольтметр В7-40",   // найменування (хар.1)
            4_800.00,            // вартість, грн (хар.4)
            220.0,               // напруга, В   (хар.7)
            0.050,               // струм,   А
            50.0                 // частота, Гц
        );

        DeviceBase ammeter = new DeviceBase(
            "Амперметр АМ-300",
            2_350.00,
            12.0,   // 12В DC
            0.100,
            0.0     // постійний струм
        );

        // DevicePro: name, basePrice, voltage, current, frequency, length, height, width
        DevicePro oscilloscope = new DevicePro(
            "Осцилограф ОСЦ-300",
            32_000.00,
            220.0, 0.800, 50.0,   // живлення
            400.0, 250.0, 180.0   // габарити мм (об'єм = 18 000 000 мм³ > 5л → ×1.30)
        );

        DevicePro multimeter = new DevicePro(
            "Мультиметр МТ-975",
            3_600.00,
            9.0, 0.025, 0.0,      // 9В DC
            175.0, 90.0, 50.0     // габарити мм (об'єм = 787 500 мм³ < 1л → ×1.00)
        );

        System.out.println("Усі об'єкти створено успішно.");

        // ══════════════════════════════════════════════════════════════════════
        // 2. ПОЛІМОРФІЗМ — виклик через AbstractDevice[]
        // ══════════════════════════════════════════════════════════════════════
        System.out.println("\n▶ 2. Поліморфізм — getDeviceInfo() та calculateCost()");
        System.out.println("─".repeat(60));

        AbstractDevice[] devices = { voltmeter, ammeter, oscilloscope, multimeter };

        for (AbstractDevice d : devices) {
            System.out.println("\n" + d.getDeviceInfo());
            System.out.printf("   calculateCost() → %.2f грн%n", d.calculateCost());
        }

        // ══════════════════════════════════════════════════════════════════════
        // 3. МЕТОДИ ДОСТУПУ get / set
        // ══════════════════════════════════════════════════════════════════════
        System.out.println("\n▶ 3. Демонстрація get / set методів");
        System.out.println("─".repeat(60));

        System.out.println("getName()          → " + voltmeter.getName());
        voltmeter.setName("Вольтметр В7-40М (оновлений)");
        System.out.println("після setName()    → " + voltmeter.getName());

        System.out.printf("getBasePrice()     → %.2f грн%n", voltmeter.getBasePrice());
        voltmeter.setBasePrice(5_100.00);
        System.out.printf("після setBasePrice → %.2f грн%n", voltmeter.getBasePrice());

        System.out.println("getPowerSource()   → " + voltmeter.getPowerSource());
        voltmeter.setPowerSource(new PowerSource(230.0, 0.060, 50.0));
        System.out.println("після setPower     → " + voltmeter.getPowerSource());

        System.out.println();
        System.out.println("getDimensions()    → " + oscilloscope.getDimensions());
        System.out.println("getSizeCategory()  → " + oscilloscope.getSizeCategory());
        System.out.printf ("getSizeCoefficient→ ×%.2f%n", oscilloscope.getSizeCoefficient());

        System.out.println();
        System.out.println("Мультиметр габарити: " + multimeter.getDimensions());
        System.out.println("getSizeCategory()  → " + multimeter.getSizeCategory());
        System.out.printf ("getSizeCoefficient→ ×%.2f%n", multimeter.getSizeCoefficient());

        // ══════════════════════════════════════════════════════════════════════
        // 4. МЕТОДИ КЕРУВАННЯ СТАНОМ
        // ══════════════════════════════════════════════════════════════════════
        System.out.println("\n▶ 4. Методи керування станом (характеристика 11)");
        System.out.println("─".repeat(60));

        System.out.println("Початковий стан амперметра: " + ammeter.getStatus());
        ammeter.powerOn();
        System.out.println("Після powerOn():            " + ammeter.getStatus());
        ammeter.powerOff();
        System.out.println("Після powerOff():           " + ammeter.getStatus());

        System.out.println();
        ammeter.markAsBroken();
        System.out.println("Після markAsBroken():       " + ammeter.getStatus());
        ammeter.powerOn();                    // спроба увімкнути несправний
        ammeter.markAsFixed();
        System.out.println("Після markAsFixed():        " + ammeter.getStatus());
        ammeter.powerOn();
        System.out.println("Після повторного powerOn(): " + ammeter.getStatus());

        // ══════════════════════════════════════════════════════════════════════
        // 5. СТАТИЧНИЙ ЛІЧИЛЬНИК
        // ══════════════════════════════════════════════════════════════════════
        System.out.println("\n▶ 5. Статичний лічильник об'єктів");
        System.out.println("─".repeat(60));
        System.out.println("AbstractDevice.getTotalDevices() = "
                + AbstractDevice.getTotalDevices());

        // ══════════════════════════════════════════════════════════════════════
        // 6. ДІАЛОГОВИЙ КОНСТРУКТОР
        // ══════════════════════════════════════════════════════════════════════
        System.out.println("\n▶ 6. Введення нового приладу DevicePro через Scanner");
        System.out.println("─".repeat(60));

        Scanner sc = new Scanner(System.in);
        System.out.println("Введіть дані для нового приладу (DevicePro):\n");
        DevicePro userDevice = new DevicePro(sc);

        System.out.println("\nСтворений прилад:");
        System.out.println(userDevice.getDeviceInfo());
        System.out.printf("calculateCost() → %.2f грн%n", userDevice.calculateCost());

        System.out.println("\nУсього об'єктів після введення: "
                + AbstractDevice.getTotalDevices());

        sc.close();
        System.out.println("\n══ Кінець Лабораторної роботи №1 ══");
    }
}
