package ua.lab.devices;

/**
 * DeviceNotFunctionalException — виняток предметної області.
 * Кидається при спробі виконати операцію над несправним приладом.
 */
public class DeviceNotFunctionalException extends DeviceException {

    private final String deviceName;

    public DeviceNotFunctionalException(String deviceName) {
        super("Прилад «" + deviceName + "» несправний. Виконання операції неможливе.");
        this.deviceName = deviceName;
    }

    /** Повертає найменування несправного приладу */
    public String getDeviceName() { return deviceName; }
}
