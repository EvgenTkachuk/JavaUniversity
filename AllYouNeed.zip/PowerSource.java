package ua.lab.devices;

/**
 * PowerSource — допоміжний клас для характеристики 7.
 * Описує джерело живлення вимірювального приладу:
 *   — напруга (В)
 *   — струм (А)
 *   — частота (Гц)
 */
public class PowerSource {

    private double voltage;   // напруга, В
    private double current;   // струм,   А
    private double frequency; // частота, Гц (0 = постійний струм)

    // ─── Конструктор ─────────────────────────────────────────────────────────
    public PowerSource(double voltage, double current, double frequency) {
        setVoltage(voltage);
        setCurrent(current);
        setFrequency(frequency);
    }

    // ─── Гетери / сетери з валідацією ────────────────────────────────────────
    public double getVoltage() { return voltage; }
    public void setVoltage(double voltage) {
        if (voltage <= 0)
            throw new IllegalArgumentException(
                "Напруга має бути > 0. Отримано: " + voltage + " В.");
        this.voltage = voltage;
    }

    public double getCurrent() { return current; }
    public void setCurrent(double current) {
        if (current <= 0)
            throw new IllegalArgumentException(
                "Струм має бути > 0. Отримано: " + current + " А.");
        this.current = current;
    }

    public double getFrequency() { return frequency; }
    public void setFrequency(double frequency) {
        if (frequency < 0)
            throw new IllegalArgumentException(
                "Частота не може бути від'ємною. Отримано: " + frequency + " Гц.");
        this.frequency = frequency;
    }

    /**
     * Потужність: P = U × I (Вт)
     */
    public double getPower() {
        return voltage * current;
    }

    /**
     * Тип струму: постійний (DC) або змінний (AC)
     */
    public String getCurrentType() {
        return frequency == 0 ? "DC (постійний)" : "AC (змінний)";
    }

    @Override
    public String toString() {
        String freq = (frequency == 0)
            ? "DC"
            : String.format("%.1f Гц", frequency);
        return String.format("%.1f В / %.3f А / %s  (P = %.2f Вт)",
            voltage, current, freq, getPower());
    }
}
