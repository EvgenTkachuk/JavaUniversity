package ua.lab.devices;

import java.util.List;

/**
 * Main2 — точка входу для Лабораторної роботи №2.
 *
 * Демонструє:
 *   1. Роботу через посилання на інтерфейси IDeviceInfo та IDeviceControl
 *   2. Константи та default-методи інтерфейсів
 *   3. Усі операції з колекцією DeviceCatalog (ArrayList)
 *   4. Обробку власних та стандартних виняткових ситуацій
 */
public class Main2 {

    public static void main(String[] args) {

        System.out.println("╔══════════════════════════════════════════════════════════╗");
        System.out.println("║  Лабораторна робота №2 — Варіант 11                     ║");
        System.out.println("║  Інтерфейси, колекції, виняткові ситуації (Java)        ║");
        System.out.println("╚══════════════════════════════════════════════════════════╝\n");

        // ══════════════════════════════════════════════════════════════════════
        // 1. РОБОТА ЧЕРЕЗ ІНТЕРФЕЙСИ
        // ══════════════════════════════════════════════════════════════════════
        System.out.println("▶ 1. Використання інтерфейсів IDeviceInfo та IDeviceControl");
        System.out.println("─".repeat(60));

        // Посилання на IDeviceInfo (перший рівень)
        IDeviceInfo infoRef = new DeviceBase(
            "Термометр ТМ-150", 1_200.00, 220.0, 0.020, 50.0
        );
        System.out.println("Через IDeviceInfo:");
        System.out.println("  getName()    → " + infoRef.getName());
        System.out.println("  getStatus()  → " + infoRef.getStatus());
        System.out.println("  константа DEFAULT_MANUFACTURER:");
        System.out.println("                 " + IDeviceInfo.DEFAULT_MANUFACTURER);

        System.out.println();

        // Посилання на IDeviceControl (другий рівень)
        IDeviceControl ctrlRef = new DevicePro(
            "Осцилограф ОСЦ-500", 45_000.00, 220.0, 1.200, 50.0,
            500.0, 300.0, 200.0  // великий: об'єм 30 000 000 мм³ → ×1.30
        );
        System.out.println("Через IDeviceControl:");
        System.out.println("  getName()         → " + ctrlRef.getName());
        System.out.printf ("  calculateCost()   → %.2f грн%n", ctrlRef.calculateCost());
        System.out.printf ("  BUDGET_PRICE_LIMIT→ %.0f грн%n", IDeviceControl.BUDGET_PRICE_LIMIT);
        System.out.println("  isBudget()        → " + ctrlRef.isBudget());
        System.out.println("  getPriceClass()   → " + ctrlRef.getPriceClass());
        ctrlRef.powerOn();
        System.out.println("  getStatus()       → " + ctrlRef.getStatus());
        ctrlRef.powerOff();

        System.out.println();

        // Бюджетний прилад
        IDeviceControl budget = new DeviceBase(
            "Тестер ТС-40", 480.00, 9.0, 0.010, 0.0
        );
        System.out.println("Бюджетний прилад:");
        System.out.printf ("  calculateCost()   → %.2f грн%n", budget.calculateCost());
        System.out.println("  isBudget()        → " + budget.isBudget());
        System.out.println("  getPriceClass()   → " + budget.getPriceClass());

        // ══════════════════════════════════════════════════════════════════════
        // 2. ЗАПОВНЕННЯ КОЛЕКЦІЇ
        // ══════════════════════════════════════════════════════════════════════
        System.out.println("\n▶ 2. Робота з колекцією DeviceCatalog (ArrayList)");
        System.out.println("─".repeat(60));

        DeviceCatalog catalog = new DeviceCatalog();

        try {
            catalog.add(new DeviceBase("Вольтметр В7-40",    4_800.00, 220.0, 0.050, 50.0));
            catalog.add(new DeviceBase("Амперметр АМ-300",   2_350.00, 12.0,  0.100,  0.0));
            catalog.add(new DeviceBase("Термометр ТМ-150",   1_200.00, 220.0, 0.020, 50.0));
            catalog.add(new DeviceBase("Тестер ТС-40",         480.00,  9.0,  0.010,  0.0));
            catalog.add(new DevicePro ("Мультиметр МТ-975",  3_600.00,  9.0,  0.025,  0.0,
                                       175.0, 90.0, 50.0));   // компактний ×1.00
            catalog.add(new DevicePro ("Осцилограф ОСЦ-300",32_000.00, 220.0, 0.800, 50.0,
                                       400.0, 250.0, 180.0)); // великий ×1.30
            catalog.add(new DevicePro ("Аналізатор АН-100",  8_500.00, 220.0, 0.150, 50.0,
                                       200.0, 120.0, 80.0));  // середній ×1.15
        } catch (InvalidDeviceParameterException e) {
            System.out.println("[Помилка] " + e.getMessage());
        }

        catalog.printSummary();

        // ──── Доступ за індексом ───────────────────────────────────────────
        System.out.println("\n── Доступ за індексом [2] ──");
        try {
            AbstractDevice d = catalog.get(2);
            System.out.printf("  [2] = «%s»  →  %.2f грн%n",
                    d.getName(), d.calculateCost());
        } catch (DeviceException e) {
            System.out.println("[DeviceException] " + e.getMessage());
        }

        // ──── Пошук за назвою ─────────────────────────────────────────────
        System.out.println("\n── Пошук за підрядком «метр» ──");
        catalog.findByNameContains("метр")
               .forEach(d -> System.out.println("  " + d.getName()));

        // ──── Пошук за типом струму ───────────────────────────────────────
        System.out.println("\n── Прилади на постійному струмі (DC) ──");
        catalog.findByCurrentType("DC")
               .forEach(d -> System.out.printf("  %-25s %s%n",
                   d.getName(), ((DeviceBase)d).getPowerSource()));

        // ──── Підколекція справних ────────────────────────────────────────
        System.out.println("\n── Справні прилади ──");
        catalog.findFunctional()
               .forEach(d -> System.out.println("  " + d.getName()
                       + " [" + d.getStatus() + "]"));

        // ──── Сортування за назвою ────────────────────────────────────────
        catalog.sortByName();
        catalog.printSummary();

        // ──── Сортування за вартістю ──────────────────────────────────────
        catalog.sortByCost();
        catalog.printSummary();

        // ──── Сортування за потужністю ────────────────────────────────────
        catalog.sortByPower();
        System.out.println("\n── Після сортування за потужністю ──");
        catalog.printSummary();

        // ──── Підколекція: ціна до 5000 грн ──────────────────────────────
        System.out.printf("%n── Прилади до %.0f грн --%n", IDeviceControl.BUDGET_PRICE_LIMIT);
        catalog.filterByCostUpTo(IDeviceControl.BUDGET_PRICE_LIMIT)
               .forEach(d -> System.out.printf("  %-25s %.2f грн%n",
                   d.getName(), d.calculateCost()));

        // ──── DevicePro окремо ────────────────────────────────────────────
        System.out.println("\n── DevicePro об'єкти з розмірним коефіцієнтом ──");
        catalog.findProDevices().forEach(p ->
            System.out.printf("  %-25s габарити: %s  коеф: ×%.2f%n",
                p.getName(), p.getDimensions(), p.getSizeCoefficient()));

        // ──── Видалення ───────────────────────────────────────────────────
        System.out.println();
        catalog.removeByName("Тестер ТС-40");
        catalog.printSummary();

        // ══════════════════════════════════════════════════════════════════════
        // 3. ОБРОБКА ВИНЯТКОВИХ СИТУАЦІЙ
        // ══════════════════════════════════════════════════════════════════════
        System.out.println("\n▶ 3. Демонстрація виняткових ситуацій");
        System.out.println("─".repeat(60));

        // ─ 3a. Від'ємна вартість ─────────────────────────────────────────────
        System.out.println("3a. Від'ємна вартість:");
        try {
            DeviceBase bad = new DeviceBase("Невірний", -500.0, 220.0, 0.05, 50.0);
        } catch (IllegalArgumentException e) {
            System.out.println("  [IllegalArgumentException] " + e.getMessage());
        }

        // ─ 3b. Некоректний струм (= 0) ───────────────────────────────────────
        System.out.println("\n3b. Нульовий струм живлення:");
        try {
            PowerSource ps = new PowerSource(220.0, 0.0, 50.0);
        } catch (IllegalArgumentException e) {
            System.out.println("  [IllegalArgumentException] " + e.getMessage());
        }

        // ─ 3c. Некоректні габарити ────────────────────────────────────────────
        System.out.println("\n3c. Від'ємна ширина Dimensions:");
        try {
            Dimensions dim = new Dimensions(100.0, 80.0, -30.0);
        } catch (IllegalArgumentException e) {
            System.out.println("  [IllegalArgumentException] " + e.getMessage());
        }

        // ─ 3d. Доступ до некоректного індексу ────────────────────────────────
        System.out.println("\n3d. Доступ за індексом [999]:");
        try {
            AbstractDevice d = catalog.get(999);
        } catch (DeviceException e) {
            System.out.println("  [DeviceException] " + e.getMessage());
        }

        // ─ 3e. Додавання null до каталогу ────────────────────────────────────
        System.out.println("\n3e. Додавання null до каталогу:");
        try {
            catalog.add(null);
        } catch (InvalidDeviceParameterException e) {
            System.out.println("  [InvalidDeviceParameterException]");
            System.out.println("  Параметр : " + e.getParameterName());
            System.out.println("  Значення : " + e.getInvalidValue());
            System.out.println("  Деталі   : " + e.getMessage());
        }

        // ─ 3f. Власний виняток: операція над несправним приладом ─────────────
        System.out.println("\n3f. Власний виняток DeviceNotFunctionalException:");
        try {
            AbstractDevice broken = catalog.get(0);
            broken.markAsBroken();
            performMeasurement(broken);
        } catch (DeviceException e) {
            System.out.println("  [DeviceException] " + e.getMessage());
            if (e instanceof DeviceNotFunctionalException) { DeviceNotFunctionalException dfne = (DeviceNotFunctionalException) e;
                System.out.println("  Назва приладу: " + dfne.getDeviceName());
            }
        }

        // ─ 3g. Видалення за некоректним індексом ─────────────────────────────
        System.out.println("\n3g. Видалення за некоректним індексом [-1]:");
        try {
            catalog.removeAt(-1);
        } catch (IndexOutOfBoundsException e) {
            System.out.println("  [IndexOutOfBoundsException] " + e.getMessage());
        }

        // ══════════════════════════════════════════════════════════════════════
        System.out.println("\n── Підсумок ──────────────────────────────────");
        System.out.println("Приладів у каталозі : " + catalog.size());
        System.out.println("Усього об'єктів     : " + AbstractDevice.getTotalDevices());
        System.out.println("══ Кінець Лабораторної роботи №2 ══");
    }

    /**
     * Допоміжний метод — кидає DeviceNotFunctionalException для несправного приладу.
     */
    private static void performMeasurement(AbstractDevice device)
            throws DeviceNotFunctionalException {
        if (!device.isFunctional())
            throw new DeviceNotFunctionalException(device.getName());
        System.out.println("  Вимірювання виконано для: " + device.getName());
    }
}
