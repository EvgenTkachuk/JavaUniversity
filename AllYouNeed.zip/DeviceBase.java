package ua.lab.devices;

import java.util.Scanner;

/**
 * DeviceBase — клас-нащадок першого рівня.
 *
 * Реалізує характеристики варіанту 11:
 *   Характеристика  1 — найменування        (AbstractDevice)
 *   Характеристика  4 — вартість приладу    (basePrice)
 *   Характеристика  7 — джерело живлення    (PowerSource)
 *   Характеристика 11 — стан приладу        (AbstractDevice)
 *
 * Реалізує абстрактні методи:
 *   getDeviceInfo()  — повна інформація
 *   calculateCost()  — повертає basePrice
 */
public class DeviceBase extends AbstractDevice {

    // ─── Характеристика 4: Вартість ──────────────────────────────────────────
    private double basePrice; // грн

    // ─── Характеристика 7: Джерело живлення ──────────────────────────────────
    private PowerSource powerSource;

    // ═════════════════════════════════════════════════════════════════════════
    // КОНСТРУКТОР З ПАРАМЕТРАМИ
    // ═════════════════════════════════════════════════════════════════════════
    /**
     * @param name        найменування приладу
     * @param basePrice   вартість, грн
     * @param voltage     напруга живлення, В
     * @param current     струм живлення, А
     * @param frequency   частота, Гц (0 = постійний струм)
     */
    public DeviceBase(String name,
                      double basePrice,
                      double voltage,
                      double current,
                      double frequency) {
        super(name);
        setBasePrice(basePrice);
        this.powerSource = new PowerSource(voltage, current, frequency);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // КОНСТРУКТОР — ДІАЛОГОВИЙ (Scanner)
    // ═════════════════════════════════════════════════════════════════════════
    public DeviceBase(Scanner sc) {
        super(promptString(sc, "Найменування приладу: "));
        setBasePrice(promptPositiveDouble(sc, "Вартість (грн): "));

        System.out.println("--- Джерело живлення ---");
        double v = promptPositiveDouble(sc, "  Напруга (В): ");
        double i = promptPositiveDouble(sc, "  Струм   (А): ");
        double f = promptDouble(sc,          "  Частота (Гц, 0=DC): ");
        this.powerSource = new PowerSource(v, i, f);
    }

    // ─── Допоміжні методи вводу ──────────────────────────────────────────────
    static String promptString(Scanner sc, String prompt) {
        System.out.print(prompt);
        String s = sc.nextLine().trim();
        while (s.isBlank()) {
            System.out.print("  Не може бути порожнім. " + prompt);
            s = sc.nextLine().trim();
        }
        return s;
    }

    static double promptPositiveDouble(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                double v = Double.parseDouble(sc.nextLine().trim().replace(',', '.'));
                if (v <= 0) { System.out.println("  Значення має бути > 0."); continue; }
                return v;
            } catch (NumberFormatException e) {
                System.out.println("  Некоректний формат числа.");
            }
        }
    }

    static double promptDouble(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Double.parseDouble(sc.nextLine().trim().replace(',', '.'));
            } catch (NumberFormatException e) {
                System.out.println("  Некоректний формат числа.");
            }
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // РЕАЛІЗАЦІЯ АБСТРАКТНИХ МЕТОДІВ
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Повна інформація про прилад (реалізація абстрактного методу).
     */
    @Override
    public String getDeviceInfo() {
        return "=== DeviceBase ===" +
               "\n  Найменування  : " + getName() +
               "\n  Вартість      : " + String.format("%.2f грн", basePrice) +
               "\n  Живлення      : " + powerSource +
               "\n  Тип струму    : " + powerSource.getCurrentType() +
               "\n  Стан          : " + getStatus();
    }

    /**
     * Вартість = базова ціна.
     * У DevicePro буде перевизначено з урахуванням розмірного коефіцієнта.
     */
    @Override
    public double calculateCost() {
        return basePrice;
    }

    // ═════════════════════════════════════════════════════════════════════════
    // МЕТОДИ ДОСТУПУ GET / SET
    // ═════════════════════════════════════════════════════════════════════════

    // ─── Вартість ─────────────────────────────────────────────────────────────
    public double getBasePrice() { return basePrice; }

    public void setBasePrice(double basePrice) {
        if (basePrice < 0)
            throw new IllegalArgumentException(
                "Вартість не може бути від'ємною. Отримано: " + basePrice);
        this.basePrice = basePrice;
    }

    // ─── Джерело живлення ────────────────────────────────────────────────────
    public PowerSource getPowerSource() { return powerSource; }

    public void setPowerSource(PowerSource ps) {
        if (ps == null)
            throw new IllegalArgumentException("PowerSource не може бути null.");
        this.powerSource = ps;
    }

    @Override
    public String toString() { return getDeviceInfo(); }
}
