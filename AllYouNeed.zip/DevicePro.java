package ua.lab.devices;

import java.util.Scanner;

/**
 * DevicePro — клас-нащадок другого рівня (розширена модель).
 *
 * Успадковує від DeviceBase всі характеристики 1, 4, 7, 11.
 * Додає:
 *   Характеристика 2 — габарити (Dimensions)  [Таблиця 2, варіант 11]
 *
 * Перевизначає:
 *   getDeviceInfo()  — додає блок габаритів
 *   calculateCost()  — вартість з розмірним коефіцієнтом (великі прилади дорожчі)
 *
 * Розмірний коефіцієнт:
 *   Якщо об'єм > 1 000 000 мм³ (1 літр) — ціна підвищується на 15 %.
 *   Якщо об'єм > 5 000 000 мм³ (5 літрів) — ціна підвищується на 30 %.
 */
public class DevicePro extends DeviceBase {

    /** Поріг об'єму для середнього збільшення ціни, мм³ */
    private static final double VOLUME_MEDIUM = 1_000_000.0;
    /** Поріг об'єму для великого збільшення ціни, мм³ */
    private static final double VOLUME_LARGE  = 5_000_000.0;
    /** Коефіцієнт для середніх приладів */
    private static final double RATE_MEDIUM   = 1.15;
    /** Коефіцієнт для великих приладів */
    private static final double RATE_LARGE    = 1.30;

    // ─── Характеристика 2: Габарити ──────────────────────────────────────────
    private Dimensions dimensions;

    // ═════════════════════════════════════════════════════════════════════════
    // КОНСТРУКТОР З ПАРАМЕТРАМИ
    // ═════════════════════════════════════════════════════════════════════════
    /**
     * @param name       найменування
     * @param basePrice  вартість, грн
     * @param voltage    напруга, В
     * @param current    струм, А
     * @param frequency  частота, Гц
     * @param length     довжина, мм
     * @param height     висота,  мм
     * @param width      ширина,  мм
     */
    public DevicePro(String name,
                     double basePrice,
                     double voltage, double current, double frequency,
                     double length, double height, double width) {
        super(name, basePrice, voltage, current, frequency);
        this.dimensions = new Dimensions(length, height, width);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // КОНСТРУКТОР — ДІАЛОГОВИЙ (Scanner)
    // ═════════════════════════════════════════════════════════════════════════
    public DevicePro(Scanner sc) {
        super(sc);
        System.out.println("--- Габарити приладу ---");
        double l = promptPositiveDouble(sc, "  Довжина (мм): ");
        double h = promptPositiveDouble(sc, "  Висота  (мм): ");
        double w = promptPositiveDouble(sc, "  Ширина  (мм): ");
        this.dimensions = new Dimensions(l, h, w);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // ПЕРЕВИЗНАЧЕННЯ АБСТРАКТНИХ МЕТОДІВ
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Розширена інформація — включає габарити та розмірний коефіцієнт.
     */
    @Override
    public String getDeviceInfo() {
        double coeff = getSizeCoefficient();
        return "=== DevicePro (розширена модель) ===" +
               "\n  Найменування     : " + getName() +
               "\n  Вартість базова  : " + String.format("%.2f грн", getBasePrice()) +
               "\n  Розм. коефіцієнт : ×" + String.format("%.2f", coeff) +
               "\n  Повна вартість   : " + String.format("%.2f грн", calculateCost()) +
               "\n  Живлення         : " + getPowerSource() +
               "\n  Тип струму       : " + getPowerSource().getCurrentType() +
               "\n  Габарити         : " + dimensions +
               "\n  Стан             : " + getStatus();
    }

    /**
     * Вартість = базова ціна × розмірний коефіцієнт.
     */
    @Override
    public double calculateCost() {
        return getBasePrice() * getSizeCoefficient();
    }

    // ═════════════════════════════════════════════════════════════════════════
    // МЕТОДИ ДОСТУПУ
    // ═════════════════════════════════════════════════════════════════════════
    public Dimensions getDimensions() { return dimensions; }

    public void setDimensions(Dimensions dimensions) {
        if (dimensions == null)
            throw new IllegalArgumentException("Dimensions не може бути null.");
        this.dimensions = dimensions;
    }

    /**
     * Розмірний коефіцієнт залежно від об'єму корпусу.
     */
    public double getSizeCoefficient() {
        double vol = dimensions.volume();
        if (vol > VOLUME_LARGE)  return RATE_LARGE;
        if (vol > VOLUME_MEDIUM) return RATE_MEDIUM;
        return 1.0;
    }

    /**
     * Текстова категорія розміру приладу.
     */
    public String getSizeCategory() {
        double vol = dimensions.volume();
        if (vol > VOLUME_LARGE)  return "Великий (> 5 л)";
        if (vol > VOLUME_MEDIUM) return "Середній (1–5 л)";
        return "Компактний (< 1 л)";
    }

    @Override
    public String toString() { return getDeviceInfo(); }
}
