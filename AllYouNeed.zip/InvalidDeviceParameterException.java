package ua.lab.devices;

/**
 * InvalidDeviceParameterException — виняток: некоректне значення параметру приладу.
 * Зберігає назву параметру та некоректне значення для діагностики.
 */
public class InvalidDeviceParameterException extends DeviceException {

    private final String parameterName;
    private final Object invalidValue;

    public InvalidDeviceParameterException(String parameterName, Object invalidValue) {
        super("Некоректне значення параметру «" + parameterName
                + "»: " + invalidValue + ".");
        this.parameterName = parameterName;
        this.invalidValue  = invalidValue;
    }

    public String getParameterName() { return parameterName; }
    public Object getInvalidValue()  { return invalidValue;  }
}
