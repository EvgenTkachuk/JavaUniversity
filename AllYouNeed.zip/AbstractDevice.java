package ua.lab.devices;

/**
 * AbstractDevice — абстрактний базовий клас ієрархії вимірювальних приладів.
 *
 * Реалізує:
 *   Характеристика  1 — найменування приладу
 *   Характеристика 11 — стан приладу (увімкнено/вимкнено, справний/несправний)
 *
 * Оголошує абстрактні методи:
 *   getDeviceInfo()  — повна інформація про прилад
 *   calculateCost()  — вартість приладу
 *
 * Статичні елементи:
 *   totalDevices — лічильник усіх створених об'єктів
 *   getTotalDevices() — повертає значення лічильника
 */
public abstract class AbstractDevice implements IDeviceControl {

    // ─── Статичні поля ────────────────────────────────────────────────────────
    /** Лічильник усіх створених об'єктів ієрархії */
    private static int totalDevices = 0;

    // ─── Характеристика 1: Найменування ──────────────────────────────────────
    private String name;

    // ─── Характеристика 11: Стан приладу ─────────────────────────────────────
    private boolean poweredOn;   // true = увімкнено
    private boolean functional;  // true = справний

    // ═════════════════════════════════════════════════════════════════════════
    // КОНСТРУКТОР
    // ═════════════════════════════════════════════════════════════════════════
    public AbstractDevice(String name) {
        setName(name);
        this.poweredOn  = false;
        this.functional = true;
        totalDevices++;
    }

    // ═════════════════════════════════════════════════════════════════════════
    // АБСТРАКТНІ МЕТОДИ
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Повертає повну інформацію про прилад.
     * Реалізується по-різному в DeviceBase та DevicePro (поліморфізм).
     */
    public abstract String getDeviceInfo();

    /**
     * Обчислює вартість приладу.
     * У DevicePro перевизначається з урахуванням розмірного коефіцієнта.
     */
    public abstract double calculateCost();

    // ═════════════════════════════════════════════════════════════════════════
    // МЕТОДИ КЕРУВАННЯ СТАНОМ (характеристика 11)
    // ═════════════════════════════════════════════════════════════════════════

    /** Увімкнути прилад */
    public void powerOn() {
        if (!functional) {
            System.out.println("[!] Прилад «" + name + "» несправний — увімкнення неможливе.");
            return;
        }
        this.poweredOn = true;
        System.out.println("[OK] Прилад «" + name + "» увімкнено.");
    }

    /** Вимкнути прилад */
    public void powerOff() {
        this.poweredOn = false;
        System.out.println("[OK] Прилад «" + name + "» вимкнено.");
    }

    /** Позначити прилад як несправний */
    public void markAsBroken() {
        this.functional = false;
        this.poweredOn  = false;
        System.out.println("[!] Прилад «" + name + "» позначено несправним.");
    }

    /** Позначити прилад як справний (після ремонту) */
    public void markAsFixed() {
        this.functional = true;
        System.out.println("[OK] Прилад «" + name + "» відремонтовано — стан: справний.");
    }

    // ─── Перевірка стану ─────────────────────────────────────────────────────
    public boolean isPoweredOn()  { return poweredOn;  }
    public boolean isFunctional() { return functional; }

    /** Текстовий опис поточного стану */
    public String getStatus() {
        String power = poweredOn  ? "увімкнено"  : "вимкнено";
        String cond  = functional ? "справний"   : "несправний";
        return power + ", " + cond;
    }

    // ═════════════════════════════════════════════════════════════════════════
    // МЕТОДИ ДОСТУПУ (характеристика 1)
    // ═════════════════════════════════════════════════════════════════════════
    public String getName() { return name; }

    public void setName(String name) {
        if (name == null || name.isBlank())
            throw new IllegalArgumentException(
                "Найменування приладу не може бути порожнім рядком.");
        this.name = name;
    }

    // ═════════════════════════════════════════════════════════════════════════
    // СТАТИЧНІ МЕТОДИ
    // ═════════════════════════════════════════════════════════════════════════

    /** Загальна кількість створених об'єктів */
    public static int getTotalDevices() { return totalDevices; }

    /** Скидання лічильника (наприклад, для unit-тестів) */
    public static void resetCounter() { totalDevices = 0; }
}
