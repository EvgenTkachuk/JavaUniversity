package ua.lab.devices;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * DeviceCatalog — каталог вимірювальних приладів.
 *
 * Внутрішня колекція: ArrayList<AbstractDevice>.
 *
 * Реалізовані операції:
 *   — додавання / видалення за індексом / видалення за назвою
 *   — доступ за індексом
 *   — пошук за назвою, за типом струму, за типом DevicePro
 *   — сортування за назвою, за вартістю, за потужністю живлення
 *   — підколекція за ціновим класом, за статусом справності
 */
public class DeviceCatalog {

    private final ArrayList<AbstractDevice> items = new ArrayList<>();

    // ══════════════════════════════════════════════════════════════════════════
    // ДОДАВАННЯ
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Додає прилад до каталогу.
     *
     * @throws InvalidDeviceParameterException якщо device == null
     */
    public void add(AbstractDevice device) throws InvalidDeviceParameterException {
        if (device == null)
            throw new InvalidDeviceParameterException("device", "null");
        items.add(device);
        System.out.println("[Каталог] Додано: «" + device.getName() + "»");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // ВИДАЛЕННЯ
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Видаляє прилад за індексом.
     *
     * @throws IndexOutOfBoundsException якщо індекс некоректний
     */
    public void removeAt(int index) {
        validateIndex(index);
        String name = items.get(index).getName();
        items.remove(index);
        System.out.println("[Каталог] Видалено [" + index + "]: «" + name + "»");
    }

    /**
     * Видаляє перший прилад із відповідною назвою (без урахування регістру).
     *
     * @return true — видалено, false — не знайдено
     */
    public boolean removeByName(String name) {
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getName().equalsIgnoreCase(name)) {
                items.remove(i);
                System.out.println("[Каталог] Видалено за назвою: «" + name + "»");
                return true;
            }
        }
        System.out.println("[Каталог] Прилад «" + name + "» не знайдено.");
        return false;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // ДОСТУП ЗА ІНДЕКСОМ
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Повертає прилад за індексом.
     *
     * @throws DeviceException якщо каталог порожній або індекс некоректний
     */
    public AbstractDevice get(int index) throws DeviceException {
        if (items.isEmpty())
            throw new DeviceException("Каталог порожній — отримати елемент неможливо.");
        if (index < 0 || index >= items.size())
            throw new DeviceException("Індекс " + index
                    + " виходить за межі. Допустимі: 0–" + (items.size() - 1) + ".");
        return items.get(index);
    }

    public int  size()    { return items.size();    }
    public boolean isEmpty() { return items.isEmpty(); }

    // ══════════════════════════════════════════════════════════════════════════
    // ПОШУК
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Пошук за підрядком у назві (без урахування регістру).
     */
    public List<AbstractDevice> findByNameContains(String sub) {
        List<AbstractDevice> res = new ArrayList<>();
        for (AbstractDevice d : items)
            if (d.getName().toLowerCase().contains(sub.toLowerCase()))
                res.add(d);
        return res;
    }

    /**
     * Усі справні прилади.
     */
    public List<AbstractDevice> findFunctional() {
        List<AbstractDevice> res = new ArrayList<>();
        for (AbstractDevice d : items)
            if (d.isFunctional()) res.add(d);
        return res;
    }

    /**
     * Усі об'єкти класу DevicePro.
     */
    public List<DevicePro> findProDevices() {
        List<DevicePro> res = new ArrayList<>();
        for (AbstractDevice d : items)
            if (d instanceof DevicePro) res.add((DevicePro) d);
        return res;
    }

    /**
     * Пошук за типом струму: "DC" або "AC".
     */
    public List<AbstractDevice> findByCurrentType(String type) {
        List<AbstractDevice> res = new ArrayList<>();
        for (AbstractDevice d : items) {
            if (d instanceof DeviceBase) {
                String ct = ((DeviceBase) d).getPowerSource().getCurrentType();
                if (ct.toUpperCase().contains(type.toUpperCase()))
                    res.add(d);
            }
        }
        return res;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // СОРТУВАННЯ
    // ══════════════════════════════════════════════════════════════════════════

    /** Сортування за назвою (A → Z) */
    public void sortByName() {
        items.sort(Comparator.comparing(AbstractDevice::getName));
        System.out.println("[Каталог] Відсортовано за назвою.");
    }

    /** Сортування за вартістю (дешевше → дорожче) */
    public void sortByCost() {
        items.sort(Comparator.comparingDouble(AbstractDevice::calculateCost));
        System.out.println("[Каталог] Відсортовано за вартістю.");
    }

    /** Сортування за потужністю живлення (менша → більша) */
    public void sortByPower() {
        items.sort((a, b) -> {
            double pa = (a instanceof DeviceBase) ? ((DeviceBase)a).getPowerSource().getPower() : 0;
            double pb = (b instanceof DeviceBase) ? ((DeviceBase)b).getPowerSource().getPower() : 0;
            return Double.compare(pa, pb);
        });
        System.out.println("[Каталог] Відсортовано за потужністю живлення.");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // ПІДКОЛЕКЦІЇ ЗА УМОВОЮ
    // ══════════════════════════════════════════════════════════════════════════

    /** Прилади з вартістю ≤ maxCost */
    public List<AbstractDevice> filterByCostUpTo(double maxCost) {
        List<AbstractDevice> res = new ArrayList<>();
        for (AbstractDevice d : items)
            if (d.calculateCost() <= maxCost) res.add(d);
        return res;
    }

    /** Лише справні та увімкнені прилади */
    public List<AbstractDevice> filterActive() {
        List<AbstractDevice> res = new ArrayList<>();
        for (AbstractDevice d : items)
            if (d.isFunctional() && d.isPoweredOn()) res.add(d);
        return res;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // ВИВЕДЕННЯ
    // ══════════════════════════════════════════════════════════════════════════

    /** Короткий список усіх приладів */
    public void printSummary() {
        System.out.println("\n┌─ Каталог (" + items.size() + " шт.) " + "─".repeat(50));
        for (int i = 0; i < items.size(); i++) {
            AbstractDevice d = items.get(i);
            System.out.printf("│ [%2d] %-30s │ %10.2f грн │ %s%n",
                    i, d.getName(), d.calculateCost(), d.getStatus());
        }
        System.out.println("└" + "─".repeat(63));
    }

    // ─── Внутрішня валідація індексу ─────────────────────────────────────────
    private void validateIndex(int index) {
        if (index < 0 || index >= items.size())
            throw new IndexOutOfBoundsException(
                "Індекс " + index + " некоректний (розмір каталогу: " + items.size() + ").");
    }
}
