package ua.lab.devices;

/**
 * DeviceException — базовий власний виняток предметної області.
 * Успадковується всіма специфічними винятками проекту.
 */
public class DeviceException extends Exception {

    public DeviceException(String message) {
        super(message);
    }

    public DeviceException(String message, Throwable cause) {
        super(message, cause);
    }
}
