package ua.lab.devices;

/**
 * Dimensions — допоміжний клас для характеристики 2.
 * Габарити приладу: довжина, висота, ширина (мм).
 * Використовується у DevicePro (Таблиця 2, варіант 11).
 */
public class Dimensions {

    private double length; // довжина, мм
    private double height; // висота,  мм
    private double width;  // ширина,  мм

    // ─── Конструктор ─────────────────────────────────────────────────────────
    public Dimensions(double length, double height, double width) {
        setLength(length);
        setHeight(height);
        setWidth(width);
    }

    // ─── Гетери / сетери ─────────────────────────────────────────────────────
    public double getLength() { return length; }
    public void setLength(double length) {
        if (length <= 0)
            throw new IllegalArgumentException(
                "Довжина має бути > 0. Отримано: " + length + " мм.");
        this.length = length;
    }

    public double getHeight() { return height; }
    public void setHeight(double height) {
        if (height <= 0)
            throw new IllegalArgumentException(
                "Висота має бути > 0. Отримано: " + height + " мм.");
        this.height = height;
    }

    public double getWidth() { return width; }
    public void setWidth(double width) {
        if (width <= 0)
            throw new IllegalArgumentException(
                "Ширина має бути > 0. Отримано: " + width + " мм.");
        this.width = width;
    }

    /**
     * Об'єм корпусу, мм³
     */
    public double volume() {
        return length * height * width;
    }

    /**
     * Площа основи, мм²
     */
    public double footprint() {
        return length * width;
    }

    @Override
    public String toString() {
        return String.format("%.1f × %.1f × %.1f мм  (Д × В × Ш),  об'єм: %.0f мм³",
            length, height, width, volume());
    }
}
