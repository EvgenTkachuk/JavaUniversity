package ua.lab.devices;

/**
 * IDeviceControl — інтерфейс другого рівня ієрархії.
 * Розширює IDeviceInfo: додає операції керування та розрахунок вартості.
 */
public interface IDeviceControl extends IDeviceInfo {

    /** Константа: гранична ціна «бюджетного» класу приладу, грн */
    double BUDGET_PRICE_LIMIT = 5_000.0;

    /**
     * Вмикає прилад.
     */
    void powerOn();

    /**
     * Вимикає прилад.
     */
    void powerOff();

    /**
     * Перевіряє справність приладу.
     * @return true — справний
     */
    boolean isFunctional();

    /**
     * Обчислює повну вартість приладу (характеристика 4 ± коефіцієнти).
     * @return вартість у гривнях
     */
    double calculateCost();

    /**
     * Default-метод: перевіряє, чи є прилад бюджетним.
     * Бюджетний = calculateCost() ≤ BUDGET_PRICE_LIMIT.
     */
    default boolean isBudget() {
        return calculateCost() <= BUDGET_PRICE_LIMIT;
    }

    /**
     * Default-метод: клас приладу за ціною.
     */
    default String getPriceClass() {
        double cost = calculateCost();
        if (cost <= BUDGET_PRICE_LIMIT)       return "Бюджетний (до 5 000 грн)";
        if (cost <= 20_000.0)                 return "Середній (5 000–20 000 грн)";
        return "Преміум (понад 20 000 грн)";
    }
}
